package br.com.centerville.churrasqueira;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChurrasqueiraApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChurrasqueiraApplication.class, args);
	}

}
